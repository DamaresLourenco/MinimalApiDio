using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

List<Todo> todos = new()
{
    new Todo { Id = 1, Title = "Exemplo: Aprender Minimal API", IsDone = false },
    new Todo { Id = 2, Title = "Exemplo: Subir no GitHub", IsDone = false }
};

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/", () => Results.Ok(new { message = "Bem-vindo à MinimalApiDio!" }));

app.MapGet("/todos", () => Results.Ok(todos))
   .WithName("GetTodos")
   .WithTags("Todos");

app.MapGet("/todos/{id:int}", (int id) =>
{
    var todo = todos.FirstOrDefault(t => t.Id == id);
    return todo is not null ? Results.Ok(todo) : Results.NotFound();
})
.WithName("GetTodoById")
.WithTags("Todos");

app.MapPost("/todos", (Todo newTodo) =>
{
    var nextId = todos.Any() ? todos.Max(t => t.Id) + 1 : 1;
    newTodo.Id = nextId;
    todos.Add(newTodo);
    return Results.Created($"/todos/{newTodo.Id}", newTodo);
})
.WithName("CreateTodo")
.WithTags("Todos");

app.MapPut("/todos/{id:int}", (int id, Todo updated) =>
{
    var todo = todos.FirstOrDefault(t => t.Id == id);
    if (todo is null) return Results.NotFound();
    todo.Title = updated.Title;
    todo.IsDone = updated.IsDone;
    return Results.Ok(todo);
})
.WithName("UpdateTodo")
.WithTags("Todos");

app.MapDelete("/todos/{id:int}", (int id) =>
{
    var todo = todos.FirstOrDefault(t => t.Id == id);
    if (todo is null) return Results.NotFound();
    todos.Remove(todo);
    return Results.NoContent();
})
.WithName("DeleteTodo")
.WithTags("Todos");

app.Run();

public class Todo
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public bool IsDone { get; set; }
}
